import React, { useRef } from 'react';
import Chart from 'react-apexcharts';
import useTrendlines from './useTrendlines';

const candleData = [
  { x: new Date("2023-06-01").getTime(), y: [132.5, 134.5, 131.5, 133.0] },
  { x: new Date("2023-06-02").getTime(), y: [133.0, 135.0, 132.0, 134.5] },
  { x: new Date("2023-06-03").getTime(), y: [134.5, 136.0, 133.5, 135.5] },
  { x: new Date("2023-06-04").getTime(), y: [135.0, 137.0, 134.0, 136.5] },
  { x: new Date("2023-06-05").getTime(), y: [136.0, 138.0, 135.0, 137.0] },
];

const TradingChart = () => {
  const {
    trendlines,
    hoveredTrendline,
    setHoveredTrendline,
    handleChartClick,
    handleTrendlineDoubleClick,
    deleteTrendline,
  } = useTrendlines();

  const chartRef = useRef(null);

  const options = {
    chart: {
      type: 'candlestick',
      height: 400,
      id: 'candles',
      events: {
        click: (event, chartContext, config) => {
          handleChartClick(event, chartContext, config);
        },
      },
      toolbar: {
        show: true,
      },
    },
    xaxis: {
      type: 'datetime',
      labels: { rotate: -45 },
    },
    yaxis: {
      tooltip: {
        enabled: true,
      },
    },
  };

  const series = [{ data: candleData }];

  // Convert data coords to pixel coords for SVG overlay
  const getCoords = (x, y) => {
    if (!chartRef.current) return { xPx: 0, yPx: 0 };

    const chartEl = chartRef.current.el;
    if (!chartEl) return { xPx: 0, yPx: 0 };

    const plotArea = chartEl.querySelector('.apexcharts-plot-area');
    const bbox = plotArea.getBoundingClientRect();

    const xaxis = candleData.map(d => d.x);
    const xMin = Math.min(...xaxis);
    const xMax = Math.max(...xaxis);

    const allY = candleData.flatMap(d => d.y);
    const yMin = Math.min(...allY);
    const yMax = Math.max(...allY);

    const xPx = bbox.left + ((x - xMin) / (xMax - xMin)) * bbox.width;
    const yPx = bbox.top + bbox.height - ((y - yMin) / (yMax - yMin)) * bbox.height;

    return { xPx, yPx };
  };

  return (
    <div style={{ position: 'relative', userSelect: 'none' }}>
      <Chart
        options={options}
        series={series}
        type="candlestick"
        height={400}
        ref={chartRef}
      />

      {/* SVG overlay for trendlines */}
      <svg
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          pointerEvents: 'none',
          width: '100%',
          height: 400,
          overflow: 'visible',
        }}
      >
        {trendlines.map((line) => {
          const startPos = getCoords(line.start.x, line.start.y);
          const endPos = getCoords(line.end.x, line.end.y);
          const midX = (startPos.xPx + endPos.xPx) / 2;
          const midY = (startPos.yPx + endPos.yPx) / 2;

          return (
            <g key={line.id} style={{ pointerEvents: 'auto' }}>
              <line
                x1={startPos.xPx}
                y1={startPos.yPx}
                x2={endPos.xPx}
                y2={endPos.yPx}
                stroke={line.color}
                strokeWidth={2}
                onDoubleClick={() => handleTrendlineDoubleClick(line)}
                onMouseEnter={() => setHoveredTrendline(line.id)}
                onMouseLeave={() => setHoveredTrendline(null)}
                style={{ cursor: 'pointer' }}
              />
              {hoveredTrendline === line.id && (
                <foreignObject
                  x={midX - 10}
                  y={midY - 10}
                  width={20}
                  height={20}
                  style={{ pointerEvents: 'auto' }}
                >
                  <div
                    onClick={() => deleteTrendline(line.id)}
                    style={{
                      cursor: 'pointer',
                      backgroundColor: 'white',
                      borderRadius: '50%',
                      width: '20px',
                      height: '20px',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '14px',
                      userSelect: 'none',
                      boxShadow: '0 0 3px rgba(0,0,0,0.3)',
                    }}
                    title="Delete trendline"
                  >
                    ×
                  </div>
                </foreignObject>
              )}
            </g>
          );
        })}
      </svg>
    </div>
  );
};

export default TradingChart;
